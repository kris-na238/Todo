const mongodb = require("mongodb");
async function dbConnection(req, res, next) {
    try{
        if (global['db']) {
            next();
        } else {
            let client = await mongodb.MongoClient.connect(process.env.DB_URL);
            if (client.db){
                console.log("cnnected to db");
                global['db'] = client.db("Todo"); // will create a database instance and store it in global variable
                next();
            }
            else {
                throw {error: "coudn't connect to db"}
            }
        }
    }
    catch(e){
        console.log("error in db connection",e)
        e.errorNo =3;
        next(e)
    }
    
}

module.exports = {dbConnection}
