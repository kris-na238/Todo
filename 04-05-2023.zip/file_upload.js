const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const mongodb = require("mongodb");
const path = require("path");
const multer = require("multer");

async function dbConnection(req, res, next) {
    if (global['db']) {
        next();
    } else {
        let client = await mongodb.MongoClient.connect("mongodb://localhost:27017");
        if (client.db){
            console.log("cnnected to db");
            global['db'] = client.db("Todo"); // will create a database instance and store it in global variable
            next();
        }
        else {
            throw {error: "coudn't connect to db"}
        }
    }
}

app.use(dbConnection);  
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json({ limit: '110mb' }));
app.use("/public", express.static(path.join(__dirname, "/public")));
app.use("/uploads", express.static(path.join(__dirname, "/uploads")));


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, __dirname+'/uploads')
    },
    filename: function (req, file, cb) {
     // const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
     // req.filename = file.fieldname + '-' + uniqueSuffix+'.png';
        req.filename = file.originalname
      cb(null, req.filename)
    }
  })
const upload = multer({ storage: storage })

app.post('/uploadphoto', upload.single('profile_photo'),async  function (req, res, next) {
    let filename =  req.filename;
    let db = global["db"];
    let upload_Obj = {
        file_url : "/uploads/"+filename
    }
    await db.collection("Uploads").insertOne(upload_Obj);
    res.send("success");
})

app.get("/", (req, res, next)=>{
    res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Document</title>
    </head>
    <body>
        <h1>Upload File</h1>
        <form action="/uploadphoto" method="post" enctype="multipart/form-data">
            <input type="file" name="profile_photo" placeholder="Upload photo"  />
            <button type="submit">Upload</button>
        </form>
    </body>
</html>
    `);
})

// app.get("/", function(req, res, next){
//     res.send(`hi`)
// })

// CREATE SERVER
app.listen(5000, function(){
    console.log("server is running at http://localhost:5000")
})


