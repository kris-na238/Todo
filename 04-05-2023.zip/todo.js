const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const mongodb = require("mongodb");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const path = require("path");
const jwtSecretKey = "MyNameisKrishna%#!@#";
const {dbConnection} = require("./middlewres/db")
const {ObjectId} = mongodb;
const multer = require("multer");
require('dotenv').config();
app.set('view engine', 'ejs');
const fs = require("fs");

app.use(dbConnection);  
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json({ limit: '110mb' }));
app.use(cookieParser());
app.use("/public", express.static(path.join(__dirname, "/public")));
app.use("/profile_pictures", express.static(path.join(__dirname, "/profile_pictures")));


app.get("/home",async function(req, res, next){
    res.sendFile(path.join(__dirname, "/views/todo.html"))
})




app.get("/login", function(req, res, next){
    try{
        res.sendFile(path.join(__dirname, "/views/login.html"));
    }
    catch(e){
       next(e);
    }
})

app.get("/register",async function(req, res, next){
    res.sendFile(path.join(__dirname, "/views/register.html"));
})



app.post("/login",async function(req, res, next){
    let {email, password} = req.body;
    let db = global["db"];
    let user = await db.collection("Users").findOne({email:email,password:password});
    if(!user){
        res.sendFile(path.join(__dirname, "/viewserror.html"));
    }
    else{
        
        let data = {
            loginTimeStamp: new Date(),
            user_email: email,
            id : user._id,
            gender :user.gender
        }
        const token = jwt.sign(data, jwtSecretKey);
        res.cookie("login_token", token);
        res.redirect("/tasklist");
    }
})
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, __dirname+'/profile_pictures')
    },
    filename: function (req, file, cb) {
     // const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
     // req.filename = file.fieldname + '-' + uniqueSuffix+'.png';
        req.filename = file.originalname
      cb(null, req.filename)
    }
  })
const upload = multer({ storage: storage })

app.post("/register",upload.single('profile_picture'), async function(req, res, next){

    fs.writeFile('server_logs.txt',"Api call : register, Payload : "+ JSON.stringify(req.body)+", time: "+ new Date(), function (err) {
        if (err) return res.send(err);
        console.log("log success");
      });

    let user = req.body;
    user.profile_picture_url = "/profile_pictures/"+req.filename;
    
    let db = global["db"];
    await db.collection("Users").insertOne(user);
    res.redirect("/login");
})

//authentication
app.use(function(req, res, next){
    let cookies  = req.cookies;
    if (!cookies.login_token) return res.json({message: "No token Found."});
    const verified = jwt.verify(cookies.login_token, jwtSecretKey);
    if (verified) {
        req.user = verified;
        next();
    }
    else {
        res.json({message:"Invalid Token"});
    }
})
app.get("/edittask/:taskid",async function(req, res, next){
    let taskid = req.params.taskid;
    let task = await db.collection("Tasks").findOne({_id : new ObjectId(taskid)});
    res.render("edittask",{task});
})
app.get("/createtask",async function(req, res, next){
    res.sendFile(path.join(__dirname, "/views/createtask.html"))
})
app.get("/tasklist",async function(req, res, next){
    let user = req.user;
    let db = global["db"];
    let userProfile = await db.collection("Users").findOne({_id : new ObjectId(user.id)},{projection:{profile_picture_url:1}})
    let tasks = await db.collection("Tasks").find({user_id : new ObjectId(user.id)}).toArray();
    res.render("tasklist",{tasks, user, userProfile});
    //res.json({result:"successful", data:tasks});
    //res.sendFile(path.join(__dirname, "/views/tasklist.html"));
})

app.get("/logout",async function(req, res, next){
    res.clearCookie("login_token");
    res.redirect("/home");
})

app.post("/updatetask",async function(req, res, next){
    let user = req.user;
    let updatedTaskObj = req.body;
    let db = global["db"];
    let _id = new mongodb.ObjectId(updatedTaskObj.taskid);
    delete updatedTaskObj.taskid;
    let isUpdated = await db.collection("Tasks").updateOne({_id:_id,user_id:new ObjectId(user.id)},{"$set":updatedTaskObj});
    if(isUpdated.modifiedCount) res.redirect("/tasklist");
    else res.json({result:"failed"});
    
})

 // delete task using body
// app.get("/deletetask",async function(req, res, next){
//     let user = req.user;
//     let taskid = req.body.taskid;
//     let db = global["db"];
//     let isdeleted= await db.collection("Tasks").deleteOne({_id:new mongodb.ObjectId(taskid),user_id:new ObjectId(user.id)});
//     if(isdeleted.deletedCount)
//     res.json({result:"successful"});
//     else res.json({result:"failed"});
// })

//delete task using params
// app.get("/deletetask/:taskid",async function(req, res, next){
//     let user = req.user;
//     let taskid = req.params.taskid;
//     let db = global["db"];
//     let isdeleted= await db.collection("Tasks").deleteOne({_id:new mongodb.ObjectId(taskid),user_id:new ObjectId(user.id)});
//     if(isdeleted.deletedCount)
//     res.redirect("/tasklist");
//     else res.json({result:"failed"});
// })
// delet task using query params
app.get("/deletetask",async function(req, res, next){
    let user = req.user;
    let taskid = req.query.taskid;
    let db = global["db"];
    let isdeleted= await db.collection("Tasks").deleteOne({_id:new mongodb.ObjectId(taskid),user_id:new ObjectId(user.id)});
    if(isdeleted.deletedCount)
    res.redirect("/tasklist");
    else res.json({result:"failed"});
})


app.get("/gettasks",async function(req, res, next){
        let user = req.user;
        let db = global["db"];
        let tasks = await db.collection("Tasks").find({user_id : new ObjectId(user.id)}).toArray();
        res.json({result:"successful", data:tasks});
})

app.post("/createtask",async function(req, res, next){
    try{
        let user = req.user;
        let task = req.body;
        task["user_id"] = new ObjectId(user.id);
        let db = global["db"];
        await db.collection("Tasks").insertOne(task);
        res.redirect("/tasklist");
    }
    catch(e){
        e.errorNo =2;
        next(e)
    }
        
})

//FIRST API
app.get("/", function(req, res, next){
    try{
        if(req.user)
        res.sendFile(path.join(__dirname, "/views/tasklist.html"));
        else
        res.redirect("/login");
    }
    catch(e){
       //res.send({message:"Something went wrong.Please try again."});
       e.errorNo=1;
       next(e);
    }
})


app.use(function(err, req, res, next){
    if(err.errorNo==1) res.status(500).json({error : "some error message 1"})
    else if(err.errorNo==2) res.status(500).json({error : "some error message 2"})
    else if(err.errorNo==3) res.status(500).json({error : "Some error occured in out db server, please try again."})
    else res.status(500).json({error : "some default error message "})
})

// CREATE SERVER
app.listen(process.env.PORT, function(){
    console.log("server is running at http://localhost:5000")
})


// post , put , patch, delete