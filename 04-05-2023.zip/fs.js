const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const mongodb = require("mongodb");
const fs = require("fs");

async function dbConnection(req, res, next) {
    if (global['db']) {
        next();
    } else {
        let client = await mongodb.MongoClient.connect("mongodb://localhost:27017");
        if (client.db){
            console.log("cnnected to db");
            global['db'] = client.db("Todo"); // will create a database instance and store it in global variable
            next();
        }
        else {
            throw {error: "coudn't connect to db"}
        }
    }
}



app.use(dbConnection);  
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json({ limit: '110mb' }));


app.get("/writefile", (req, res, next)=>{
    fs.writeFile('intro.txt', 'I am Software Engineer', function (err) {
        if (err) return res.send(err);
        res.send("success");
      });

})

app.get("/readfile", (req, res, next)=>{
    fs.readFile('intro.txt', 'utf-8', function (err, data) {
        if (err) return res.send(err);
        res.send(data);
      });

})


app.get("/updatefile", (req, res, next)=>{
    fs.appendFile('intro.txt', 'I live in Gurugram.', function (err) {
        if (err) return res.send(err);
        res.send("success");
      });

})


app.get("/deletefile", (req, res, next)=>{
    fs.unlink('intro.txt', function (err) {
        if (err) return res.send(err);
        res.send("success");
      });

})

//FIRST API
app.get("/", function(req, res, next){
    res.send("Hello There! hOW ARE YOU ")
})

// CREATE SERVER
app.listen(5000, function(){
    console.log("server is running at http://localhost:5000")
})


// post , put , patch, delete