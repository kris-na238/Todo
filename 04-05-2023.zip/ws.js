const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const mongodb = require("mongodb");
const path = require("path");

const express_ws = require('express-ws');
const ws = express_ws(app)
const aWss = ws.getWss('/');

async function dbConnection(req, res, next) {
    if (global['db']) {
        next();
    } else {
        let client = await mongodb.MongoClient.connect("mongodb://localhost:27017");
        if (client.db){
            console.log("cnnected to db");
            global['db'] = client.db("Todo"); // will create a database instance and store it in global variable
            next();
        }
        else {
            throw {error: "coudn't connect to db"}
        }
    }
}

app.use(dbConnection);  
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json({ limit: '110mb' }));

app.use("/public", express.static(path.join(__dirname, "/public")));

app.ws('/', (ws, req) => {
    console.error('websocket connection');
    ws.onmessage =async function (msg) {
        let db = global["db"];
        await db.collection("Messages").insertOne({message:msg.data});

        console.log(msg.data);  // msg.data = "Hi"
        aWss.clients.forEach(function (client) {
            client.send(msg.data);
        });
    };
});

//FIRST API
app.get("/chatwindow", function(req, res, next){
    res.sendFile(path.join(__dirname, "/views/chatwindow.html"))
})

app.get("/", function(req, res, next){
    res.send(`hi`)
})

// CREATE SERVER
app.listen(5000, function(){
    console.log("server is running at http://localhost:5000")
})


